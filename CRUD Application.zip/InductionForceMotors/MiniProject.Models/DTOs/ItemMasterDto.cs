﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject.Models.DTOs
{
    public class ItemMasterDto
    {
        public string ItemCode { get; set; }
        public string Description { get; set; }
        public string LocCode { get; set; }
        public string? CompanyCode { get; set; }
        public int Length { get; set; }
    }

    public class ItemMasterResponseDto
    {
        public Guid ItemMasterUuid { get; set; }
        public string ItemCode { get; set; }
        public string Description { get; set; }
        public string LocCode { get; set; }
        public string? CompanyCode { get; set; }
        public int Length { get; set; }
    }
    public class ItemMasterDeleteDto
    {
        public Guid ItemMasterUuid { get; set; }
    }
    public class ItemMasterCreateDto
    {
        public string ItemCode { get; set; }      
        public string Description { get; set; }   
               
        public string LocCode { get; set; }       
        public string CompanyCode { get; set; }
        public int Length { get; set; }
    }
    public class ItemMasterUpdateDto 
    {
        public Guid ItemMasterUuid { get; set; }
        public string ItemCode { get; set; }
        public string Description { get; set; }
        public Guid? LastUpdatedBy { get; set; }
        
        public string LocCode { get; set; }
        public string CompanyCode { get; set; }
        public decimal? Length { get; set; }

    }
    public class ItemMasterRequestDto
    {
        public string SortBy { get; set; } = "ITEM_CODE";
        public bool SortDescending { get; set; } = false;

        public int Page { get; set; } = 1;

        public int PageSize { get; set; } = 10;

        public string SearchTerm { get; set; } = string.Empty;
    }
}
