﻿namespace MiniProject.Models.Entities
{
    public class ItemMaster
    {
        public Guid ItemMasterUuid { get; set; }  
        public string ItemCode { get; set; }      
        public string Description { get; set; }   
        public Guid? CreatedBy { get; set; }      
        public DateTime? CreatedOn { get; set; }  
        public Guid? LastUpdatedBy { get; set; }  
        public DateTime? LastUpdatedOn { get; set; }
        public bool IsDeleted { get; set; }       
        public string LocCode { get; set; }       
        public string CompanyCode { get; set; }   
        public int Length { get; set; }

        public ItemMaster()
        {
            ItemMasterUuid = Guid.NewGuid();
            CreatedOn = DateTime.Now;
            IsDeleted = false;
        }

    }
}
