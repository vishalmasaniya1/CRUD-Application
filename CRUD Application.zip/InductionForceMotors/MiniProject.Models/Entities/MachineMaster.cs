﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject.Models.Entities
{
    public class MachineMaster
    {
        public Guid MachineMasterUuid { get; set; } 
        public string MachineNo { get; set; }       
        public string CostCentre { get; set; }      
        public string LineNumber { get; set; }      
        public string MachineGroup { get; set; }    
        public string Description { get; set; }     
        public string PrevMaintInd { get; set; }    
        public int? YearInstal { get; set; }        
        public string Make { get; set; }            
        public string LineIncharge { get; set; }    
        public string LineSupervisor { get; set; }  
        public string UtilInd { get; set; }         
        public string NewCostCentre { get; set; }   
        public string CriticalFlag { get; set; }    
        public DateTime? CapitalisedDate { get; set; } 
        public string Blocked { get; set; }        
        public DateTime? CreatedOn { get; set; }    
        public DateTime? LastUpdatedOn { get; set; } 
        public bool IsDeleted { get; set; }         
        public string LocCode { get; set; }         
        public string CompanyCode { get; set; }     
        public string Scrap { get; set; }           
        public string Vendor { get; set; }         
        public string NotInUse { get; set; }        
        public Guid? LastUpdatedBy { get; set; }    
        public Guid? CreatedBy { get; set; }        

        public MachineMaster()
        {
            MachineMasterUuid = Guid.NewGuid();
            CreatedOn = DateTime.Now;
            IsDeleted = false;
        }
    }
}
