﻿using MiniProject.DAL.Repositories;
using MiniProject.DAL.UnitOfWork;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.BLL
{
    public class ItemMasterService : IItemMasterService
    {
        private readonly IUnitOfWork _unitOfWork;

        public ItemMasterService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public ItemMaster Create(ItemMasterCreateDto itemMasterCreateDto)
        {
            var createdItem = _unitOfWork.ItemMasterRepository.Add(itemMasterCreateDto);
            _unitOfWork.Commit();
            return createdItem;
        }

        public bool Update(ItemMasterUpdateDto itemMasterUpdateDto)
        {
            var isUpdated = _unitOfWork.ItemMasterRepository.Update(itemMasterUpdateDto);

            if (isUpdated)
            {
                
                _unitOfWork.Commit();
            }

            return isUpdated;

        }

        public bool Delete(ItemMasterDeleteDto deleteDto)
        {
            var isDeleted = _unitOfWork.ItemMasterRepository.Delete(deleteDto.ItemMasterUuid);

            if (isDeleted)
            {
                _unitOfWork.Commit(); 
            }

            return isDeleted;
        }

        public ItemMaster GetById(Guid itemMasterUuid)
        {
            return _unitOfWork.ItemMasterRepository.GetById(itemMasterUuid);
        }

        public IEnumerable<ItemMaster> GetAll()
        {
            return _unitOfWork.ItemMasterRepository.GetAll();
        }
        public List<ItemMaster> GetPaginatedItemMasters(ItemMasterRequestDto requestDto)
        {
            return _unitOfWork.ItemMasterRepository.GetPaginatedItemMasters(requestDto);
        }

    }

}
