﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.BLL
{
    public interface IItemMasterService
    {
        ItemMaster Create(ItemMasterCreateDto itemMasterCreateDto);
        bool Update(ItemMasterUpdateDto itemMasterUpdateDto);
        bool Delete(ItemMasterDeleteDto deleteDto);
        ItemMaster GetById(Guid itemMasterUuid);
        IEnumerable<ItemMaster> GetAll();

        public List<ItemMaster> GetPaginatedItemMasters(ItemMasterRequestDto requestDto);
    }
}
