﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniProject.DAL.UnitOfWork;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.BLL
{
    public class MachineMasterService : IMachineMasterService
    {
        private readonly IUnitOfWork _unitOfWork;

        public MachineMasterService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public void Create(MachineMaster machineMaster)
        {
            
            var existingMachine = _unitOfWork.MachineMasterRepository.GetByUuid(machineMaster.MachineMasterUuid);
            if (existingMachine != null)
            {
                throw new Exception("Machine Master with this UUID already exists.");
            }

            _unitOfWork.MachineMasterRepository.Add(machineMaster);
            _unitOfWork.Commit();
        }

        public void Update(MachineMasterUpdateDto machineMasterUpdateDto)
        {
            
            var existingMachine = _unitOfWork.MachineMasterRepository.GetByUuid(machineMasterUpdateDto.MachineMasterUuid);
            if (existingMachine == null)
            {
                throw new Exception("Machine Master not found.");
            }

            _unitOfWork.MachineMasterRepository.Update(machineMasterUpdateDto);
            _unitOfWork.Commit();
        }

        public void Delete(Guid machineMasterUuid)
        {
            
            var existingMachine = _unitOfWork.MachineMasterRepository.GetByUuid(machineMasterUuid);
            if (existingMachine == null)
            {
                throw new Exception("Machine Master not found.");
            }

            _unitOfWork.MachineMasterRepository.Delete(machineMasterUuid);
            _unitOfWork.Commit();
        }

        public MachineMaster GetByUuid(Guid machineMasterUuid)
        {
            var machine = _unitOfWork.MachineMasterRepository.GetByUuid(machineMasterUuid);
            if (machine == null)
            {
                throw new Exception("Machine Master not found.");
            }

            return machine;
        }

        public IEnumerable<MachineMaster> GetAll()
        {
            return _unitOfWork.MachineMasterRepository.GetAll();
        }
        public List<MachineMaster> GetPaginatedMachineMasters(MachineMasterRequestDto requestDto)
        {
            return _unitOfWork.MachineMasterRepository.GetPaginatedMachineMasters(requestDto);
        }
    }

}
