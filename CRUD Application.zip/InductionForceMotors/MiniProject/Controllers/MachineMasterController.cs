﻿using Microsoft.AspNetCore.Mvc;
using MiniProject.BLL;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;
using Swashbuckle.AspNetCore.Annotations;

namespace MiniProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MachineMasterController : ControllerBase
    {
        private readonly IMachineMasterService _machineMasterService;

        public MachineMasterController(IMachineMasterService machineMasterService)
        {
            _machineMasterService = machineMasterService;
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Retrieve all MachineMaster entries", Description = "Gets all the items from the MachineMaster table.")]
        [ProducesResponseType(typeof(IEnumerable<MachineMaster>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<IEnumerable<MachineMaster>> GetAll()
        {
            try
            {
                var machines = _machineMasterService.GetAll();
                return Ok(machines);
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        [HttpGet("{id:guid}")]
        [SwaggerOperation(Summary = "Retrieve a specific MachineMaster by UUID", Description = "Gets a single MachineMaster entry.")]
        [ProducesResponseType(typeof(MachineMaster), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetByUuid(Guid id)
        {
            try
            {
                var machine = _machineMasterService.GetByUuid(id);
                return Ok(machine);
            }
            catch (Exception ex)
            {
                return NotFound(new { Message = ex.Message });
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Create a new MachineMaster entry", Description = "Adds a new entry to the MachineMaster table.")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Create([FromBody] MachineMaster machineMaster)
        {
            try
            {
                _machineMasterService.Create(machineMaster);
                return CreatedAtAction(nameof(GetByUuid), new { id = machineMaster.MachineMasterUuid }, machineMaster);
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        [HttpPut]
        [SwaggerOperation(Summary = "Update an existing MachineMaster entry", Description = "edit an existing entry to the MachineMaster table.")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Update([FromBody] MachineMasterUpdateDto machineMasterUpdateDto)
        {
            try
            {
                _machineMasterService.Update(machineMasterUpdateDto);
                return Ok(new { Message = "Machine Master updated successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        [HttpDelete]
        [SwaggerOperation(Summary = "Delete a specific MachineMaster by UUID", Description = "Deletes a single MachineMaster entry.")]
        public IActionResult Delete([FromBody] MachineMasterDeleteDto deleteDto)
        {
            try
            {
                _machineMasterService.Delete(deleteDto.MachineMasterUuid);
                return Ok(new { Message = "Machine Master deleted successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        [HttpGet("paginated")]
        public IActionResult GetPaginatedMachineMasters([FromQuery] MachineMasterRequestDto requestDto)
        {
            try
            {
                var machines = _machineMasterService.GetPaginatedMachineMasters(requestDto);
                return Ok(machines);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }

}
