﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MiniProject.BLL;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;
using Swashbuckle.AspNetCore.Annotations;

namespace MiniProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemMasterController : ControllerBase
    {
        private readonly IItemMasterService _itemMasterService;

        public ItemMasterController(IItemMasterService itemMasterService)
        {
            _itemMasterService = itemMasterService;
        }

        [HttpGet("{id}")]
        [SwaggerOperation(Summary = "Retrieve a specific ItemMaster by UUID", Description = "Gets a single ItemMaster entry.")]
        [ProducesResponseType(typeof(ItemMasterDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ItemMaster> Get(Guid id)
        {
            var item = _itemMasterService.GetById(id);
            if (item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }
        
        [HttpGet]
        [SwaggerOperation(Summary = "Retrieve all ItemMaster entries", Description = "Gets all the items from the ItemMaster table.")]
        [ProducesResponseType(typeof(IEnumerable<ItemMasterDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<IEnumerable<ItemMaster>> GetAll()
        {
            return Ok(_itemMasterService.GetAll());
        }

        
        [HttpPost]
        [SwaggerOperation(Summary = "Create a new ItemMaster entry", Description = "Adds a new entry to the ItemMaster table.")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Create( ItemMasterCreateDto itemMasterCreateDto )
        {
            try
            {
                var createdItem = _itemMasterService.Create(itemMasterCreateDto);
               
                return CreatedAtAction(nameof(Get), new { id = createdItem.ItemMasterUuid }, createdItem);
            }
            catch (InvalidOperationException ex)
            {

                return Conflict(new { message = "Item with the same UUID already exists." });
            }
            catch (Exception ex)
            {

                return StatusCode(500, new { message = "An unexpected error occurred.", details = ex.Message });
            }

        }

        [HttpPut]
        [SwaggerOperation(Summary = "Update an existing ItemMaster entry", Description = "edit an existing entry to the ItemMaster table.")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Update([FromBody] ItemMasterUpdateDto itemMasterUpdateDto)
        {
            try
            {
                var isUpdated = _itemMasterService.Update(itemMasterUpdateDto);

                if (!isUpdated)
                {

                    return NotFound(new { message = "Item with the provided UUID does not exist." });
                }
                return Ok(new { message = "Item updated successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

        }

        [HttpDelete]
        [SwaggerOperation(Summary = "Delete a specific ItemMaster by UUID", Description = "Deletes a single ItemMaster entry.")]
        public IActionResult Delete([FromBody] ItemMasterDeleteDto deleteDto)
        {
            try
            {

                var isDeleted = _itemMasterService.Delete(deleteDto);


                if (isDeleted)
                {
                    return Ok("Item deleted successfully.");
                }

                return NotFound("Item not found or already deleted.");
            }
            catch (SqlException ex)
            {

                return StatusCode(500, $"A database error occurred: {ex.Message}");
            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An unexpected error occurred: {ex.Message}");
            }
        }
        [HttpGet("paginated")]
        public IActionResult GetPaginatedItemMasters([FromQuery] ItemMasterRequestDto requestDto)
        {
            try
            {
                var items = _itemMasterService.GetPaginatedItemMasters(requestDto);
                return Ok(items); 
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = "An error occurred while fetching the itemMaster", Error = ex.Message });
            }
        }


    }

}
