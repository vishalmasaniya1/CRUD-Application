IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'ForceDb')
BEGIN
  CREATE DATABASE ForceDb;
END