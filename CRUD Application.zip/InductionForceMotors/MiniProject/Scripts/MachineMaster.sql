
USE ForceDb;

-- Check if the MACHINE_MASTER table exists
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MachineMaster')
BEGIN
    CREATE TABLE MachineMaster (
        MachineNo char(30) NOT NULL,
       CostCentre char(30) NULL,
       LineNumber char(30) NULL,
       MachineGroup char(30) NULL,
       Description varchar(30) NULL,
       PrevMaintInd char(30) NULL,
       YearInstal numeric(6, 0) NULL,
       Make varchar(30) NULL,
       LineIncharge char(30) NULL,
       LineSupervisor char(30) NULL,
       UtilInd char(10) NULL,
       NewCostCentre char(30) NULL,
       CriticalFlag varchar(10) NULL,
       CapitalisedDate datetime2(0) NULL,
       Blocked varchar(10) NULL,
       CreatedOn datetime NULL,
       LastUpdatedOn datetime NULL,
       IsDeleted BIT NOT NULL DEFAULT 0,
       LocCode nvarchar(10) NOT NULL,
       CompanyCode nvarchar(10) NULL,
       Scrap nvarchar(10) NULL,
       Vendor nvarchar(10) NULL,
       NotInUse nvarchar(10) NULL,
       LastUpdatedBy uniqueidentifier NULL,
       CreatedBy uniqueidentifier NULL,
       MachineMasterUuid uniqueidentifier NOT NULL,
       CONSTRAINT PK_MachineMasterUuid PRIMARY KEY CLUSTERED (MachineMasterUuid ASC)
       );
     ALTER TABLE MachineMaster ADD DEFAULT (newid()) FOR MachineMasterUuid;
END;
