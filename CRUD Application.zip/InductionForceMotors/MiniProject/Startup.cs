﻿using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Models;
using MiniProject.BLL;
using MiniProject.DAL.DatabaseInitializer;
using MiniProject.DAL.Repositories;
using MiniProject.DAL.UnitOfWork;



namespace MiniProject
{
    public class Startup
    {
        public readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");

            services.AddSingleton<DatabaseInitializer>();
            services.AddScoped<IUnitOfWork>(_ => new UnitOfWork(connectionString));
            services.AddScoped<IItemMasterService, ItemMasterService>();
            services.AddScoped<IMachineMasterService, MachineMasterService>();

            
            services.AddAuthentication();
            services.AddControllers();
            services.AddAuthorization();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ForceMotorsProject", Version = "v1", Description = "A CRUD application based on .Net core web api." });
                c.EnableAnnotations();
            }
            );
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Mini Project V1");
                c.RoutePrefix = "swagger";
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            var databaseInitializer = app.ApplicationServices.GetRequiredService<DatabaseInitializer>();
            databaseInitializer.Initialize();
        }
    }
}
