﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client;
using MiniProject.DAL.Repositories;

namespace MiniProject.DAL.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SqlConnection _connection;
        private readonly SqlTransaction _transaction;

        public IItemMasterRepository ItemMasterRepository { get; }
        public IMachineMasterRepository MachineMasterRepository { get; }

        public UnitOfWork(string connectionString)
        {
            _connection = new SqlConnection(connectionString);
            _connection.Open();
            _transaction = _connection.BeginTransaction();

            ItemMasterRepository = new ItemMasterRepository(_connection, _transaction);
            MachineMasterRepository = new MachineMasterRepository(_connection, _transaction);
        }

            public void Commit()
        {
            _transaction?.Commit();
            
        }

        public void Dispose()
        {
            _transaction?.Dispose();
            _connection?.Dispose();
        }
    }

}
