﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniProject.DAL.Repositories;

namespace MiniProject.DAL.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IItemMasterRepository ItemMasterRepository { get; }
        IMachineMasterRepository MachineMasterRepository { get; }

        void Commit();

    }
}
