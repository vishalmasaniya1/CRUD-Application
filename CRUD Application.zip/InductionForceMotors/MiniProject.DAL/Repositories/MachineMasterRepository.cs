﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.DAL.Repositories
{
    public class MachineMasterRepository : IMachineMasterRepository
    {
        private readonly SqlConnection _connection;
        private readonly SqlTransaction _transaction;

        public MachineMasterRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public void Add(MachineMaster machineMaster)
        {
            var query = @"INSERT INTO MachineMaster 
                      (MachineNo, CostCentre, LineNumber, MachineGroup, Description, PrevMaintInd, YearInstal, Make, LineIncharge, LineSupervisor, UtilInd, NewCostCentre, CriticalFlag, CapitalisedDate, Blocked, CreatedOn, LocCode, CompanyCode, Scrap, Vendor, NotInUse, CreatedBy)
                      VALUES 
                      (@MachineNo, @CostCentre, @LineNumber, @MachineGroup, @Description, @PrevMaintInd, @YearInstal, @Make, @LineIncharge, @LineSupervisor, @UtilInd, @NewCostCentre, @CriticalFlag, @CapitalisedDate, @Blocked, @CreatedOn, @LocCode, @CompanyCode, @Scrap, @Vendor, @NotInUse, @CreatedBy)";
            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@MachineNo", machineMaster.MachineNo);
            command.Parameters.AddWithValue("@CostCentre", machineMaster.CostCentre ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LineNumber", machineMaster.LineNumber ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@MachineGroup", machineMaster.MachineGroup ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Description", machineMaster.Description ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@PrevMaintInd", machineMaster.PrevMaintInd ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@YearInstal", machineMaster.YearInstal ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Make", machineMaster.Make ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LineIncharge", machineMaster.LineIncharge ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LineSupervisor", machineMaster.LineSupervisor ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@UtilInd", machineMaster.UtilInd ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@NewCostCentre", machineMaster.NewCostCentre ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CriticalFlag", machineMaster.CriticalFlag ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CapitalisedDate", machineMaster.CapitalisedDate ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Blocked", machineMaster.Blocked ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CreatedOn", machineMaster.CreatedOn ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@IsDeleted", machineMaster.IsDeleted);
            command.Parameters.AddWithValue("@LocCode", machineMaster.LocCode);
            command.Parameters.AddWithValue("@CompanyCode", machineMaster.CompanyCode ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Scrap", machineMaster.Scrap ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Vendor", machineMaster.Vendor ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@NotInUse", machineMaster.NotInUse ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CreatedBy", machineMaster.CreatedBy ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@MachineMasterUuid", machineMaster.MachineMasterUuid);
            command.ExecuteNonQuery();
        }

        public void Update(MachineMasterUpdateDto machineMasterUpdateDto)
        {
            var query = @"UPDATE MachineMaster
                      SET MachineNo = @MachineNo, CostCentre = @CostCentre, LineNumber = @LineNumber, MachineGroup = @MachineGroup, Description = @Description,
                          PrevMaintInd = @PrevMaintInd, YearInstal = @YearInstal, Make = @Make, LineIncharge = @LineIncharge, LineSupervisor = @LineSupervisor,
                          UtilInd = @UtilInd, NewCostCentre = @NewCostCentre, CriticalFlag = @CriticalFlag, CapitalisedDate = @CapitalisedDate, Blocked = @Blocked,
                          LastUpdatedOn = @LastUpdatedOn, LocCode = @LocCode, CompanyCode = @CompanyCode, Scrap = @Scrap, Vendor = @Vendor, NotInUse = @NotInUse,
                          LastUpdatedBy = @LastUpdatedBy
                      WHERE MachineMasterUuid = @MachineMasterUuid";
            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@MachineNo", machineMasterUpdateDto.MachineNo);
            command.Parameters.AddWithValue("@CostCentre", machineMasterUpdateDto.CostCentre ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LineNumber", machineMasterUpdateDto.LineNumber ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@MachineGroup", machineMasterUpdateDto.MachineGroup ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Description", machineMasterUpdateDto.Description ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@PrevMaintInd", machineMasterUpdateDto.PrevMaintInd ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@YearInstal", machineMasterUpdateDto.YearInstal ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Make", machineMasterUpdateDto.Make ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LineIncharge", machineMasterUpdateDto.LineIncharge ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LineSupervisor", machineMasterUpdateDto.LineSupervisor ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@UtilInd", machineMasterUpdateDto.UtilInd ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@NewCostCentre", machineMasterUpdateDto.NewCostCentre ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CriticalFlag", machineMasterUpdateDto.CriticalFlag ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CapitalisedDate", machineMasterUpdateDto.CapitalisedDate ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Blocked", machineMasterUpdateDto.Blocked ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LastUpdatedOn", machineMasterUpdateDto.LastUpdatedOn ?? DateTime.UtcNow);
            command.Parameters.AddWithValue("@LocCode", machineMasterUpdateDto.LocCode);
            command.Parameters.AddWithValue("@CompanyCode", machineMasterUpdateDto.CompanyCode ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Scrap", machineMasterUpdateDto.Scrap ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Vendor", machineMasterUpdateDto.Vendor ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@NotInUse", machineMasterUpdateDto.NotInUse ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LastUpdatedBy", machineMasterUpdateDto.LastUpdatedBy ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@MachineMasterUuid", machineMasterUpdateDto.MachineMasterUuid);
            command.ExecuteNonQuery();
        }

        public void Delete(Guid machineMasterUuid)
        {
            var query = @"UPDATE MachineMaster
                      SET IsDeleted = 1
                      WHERE MachineMasterUuid = @MachineMasterUuid";
            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@MachineMasterUuid", machineMasterUuid);
            command.ExecuteNonQuery();
        }

        public MachineMaster GetByUuid(Guid machineMasterUuid)
        {
            var query = @"SELECT * FROM MachineMaster WHERE MachineMasterUuid = @MachineMasterUuid AND IsDeleted = 0";
            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@MachineMasterUuid", machineMasterUuid);
            using var reader = command.ExecuteReader();

            if (reader.Read())
            {
                return new MachineMaster
                {
                    MachineMasterUuid = (Guid)reader["MachineMasterUuid"],
                    MachineNo = reader["MachineNo"].ToString(),
                    CostCentre = reader["CostCentre"] as string,
                    LineNumber = reader["LineNumber"] as string,
                    MachineGroup = reader["MachineGroup"] as string,
                    Description = reader["Description"] as string,
                    PrevMaintInd = reader["PrevMaintInd"] as string,
                    YearInstal = reader["YearInstal"] as int?,
                    Make = reader["Make"] as string,
                    LineIncharge = reader["LineIncharge"] as string,
                    LineSupervisor = reader["LineSupervisor"] as string,
                    UtilInd = reader["UtilInd"] as string,
                    NewCostCentre = reader["NewCostCentre"] as string,
                    CriticalFlag = reader["CriticalFlag"] as string,
                    CapitalisedDate = reader["CapitalisedDate"] as DateTime?,
                    Blocked = reader["Blocked"] as string,
                    CreatedOn = reader["CreatedOn"] as DateTime?,
                    LastUpdatedOn = reader["LastUpdatedOn"] as DateTime?,
                    IsDeleted = (bool)reader["IsDeleted"],
                    LocCode = reader["LocCode"].ToString(),
                    CompanyCode = reader["CompanyCode"] as string,
                    Scrap = reader["Scrap"] as string,
                    Vendor = reader["Vendor"] as string,
                    NotInUse = reader["NotInUse"] as string,
                    LastUpdatedBy = reader["LastUpdatedBy"] as Guid?,
                    CreatedBy = reader["CreatedBy"] as Guid?
                };
            }

            return null;
        }

        public IEnumerable<MachineMaster> GetAll()
        {
            var query = @"SELECT * FROM MachineMaster WHERE IsDeleted = 0";
            using var command = new SqlCommand(query, _connection, _transaction);
            using var reader = command.ExecuteReader();

            var machineMasters = new List<MachineMaster>();
            while (reader.Read())
            {
                machineMasters.Add(new MachineMaster
                {
                    MachineMasterUuid = (Guid)reader["MachineMasterUuid"],
                    MachineNo = reader["MachineNo"].ToString(),
                    CostCentre = reader["CostCentre"] as string,
                    LineNumber = reader["LineNumber"] as string,
                    MachineGroup = reader["MachineGroup"] as string,
                    Description = reader["Description"] as string,
                    PrevMaintInd = reader["PrevMaintInd"] as string,
                    YearInstal = reader["YearInstal"] as int?,
                    Make = reader["Make"] as string,
                    LineIncharge = reader["LineIncharge"] as string,
                    LineSupervisor = reader["LineSupervisor"] as string,
                    UtilInd = reader["UtilInd"] as string,
                    NewCostCentre = reader["NewCostCentre"] as string,
                    CriticalFlag = reader["CriticalFlag"] as string,
                    CapitalisedDate = reader["CapitalisedDate"] as DateTime?,
                    Blocked = reader["Blocked"] as string,
                    CreatedOn = reader["CreatedOn"] as DateTime?,
                    LastUpdatedOn = reader["LastUpdatedOn"] as DateTime?,
                    IsDeleted = (bool)reader["IsDeleted"],
                    LocCode = reader["LocCode"].ToString(),
                    CompanyCode = reader["CompanyCode"] as string,
                    Scrap = reader["Scrap"] as string,
                    Vendor = reader["Vendor"] as string,
                    NotInUse = reader["NotInUse"] as string,
                    LastUpdatedBy = reader["LastUpdatedBy"] as Guid?,
                    CreatedBy = reader["CreatedBy"] as Guid?

                });
            }

            return machineMasters;
        }
        public List<MachineMaster> GetPaginatedMachineMasters(MachineMasterRequestDto requestDto)
        {
            var machineMasterList = new List<MachineMaster>();
            var query = "SELECT MachineMasterUuid, MachineNo, CostCentre, LineNumber, Description, MachineGroup, LocCode, CompanyCode, PrevMaintInd, YearInstal, Make, LineIncharge, LineSupervisor, UtilInd, NewCostCentre, CriticalFlag, CapitalisedDate, Blocked, CreatedOn, LastUpdatedOn, IsDeleted, Scrap, Vendor, NotInUse, LastUpdatedBy, CreatedBy FROM MachineMaster ";
            if (!string.IsNullOrEmpty(requestDto.SearchTerm))
            {
                query += " WHERE MachineNo LIKE @SearchTerm ";

            }
            var sortDirection = requestDto.SortDescending ? "DESC" : "ASC";
            query += "ORDER BY " + requestDto.SortBy + " " + sortDirection;

            query += " OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";
            using (var command = new SqlCommand(query, _connection, _transaction))
            {
                command.Parameters.AddWithValue("@Offset", (requestDto.Page - 1) * requestDto.PageSize);
                command.Parameters.AddWithValue("@PageSize", requestDto.PageSize);
                if (!string.IsNullOrEmpty(requestDto.SearchTerm))
                {
                    command.Parameters.AddWithValue("@SearchTerm", "%" + requestDto.SearchTerm + "%");
                }
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        machineMasterList.Add(new MachineMaster
                        {
                            MachineMasterUuid = (Guid)reader["MachineMasterUuid"],
                            MachineNo = reader["MachineNo"].ToString(),
                            CostCentre = reader["CostCentre"] as string,
                            LineNumber = reader["LineNumber"] as string,
                            MachineGroup = reader["MachineGroup"] as string,
                            Description = reader["Description"] as string,
                            PrevMaintInd = reader["PrevMaintInd"] as string,
                            YearInstal = reader["YearInstal"] as int?,
                            Make = reader["Make"] as string,
                            LineIncharge = reader["LineIncharge"] as string,
                            LineSupervisor = reader["LineSupervisor"] as string,
                            UtilInd = reader["UtilInd"] as string,
                            NewCostCentre = reader["NewCostCentre"] as string,
                            CriticalFlag = reader["CriticalFlag"] as string,
                            CapitalisedDate = reader["CapitalisedDate"] as DateTime?,
                            Blocked = reader["Blocked"] as string,
                            CreatedOn = reader["CreatedOn"] as DateTime?,
                            LastUpdatedOn = reader["LastUpdatedOn"] as DateTime?,
                            IsDeleted = (bool)reader["IsDeleted"],
                            LocCode = reader["LocCode"].ToString(),
                            CompanyCode = reader["CompanyCode"] as string,
                            Scrap = reader["Scrap"] as string,
                            Vendor = reader["Vendor"] as string,
                            NotInUse = reader["NotInUse"] as string,
                            LastUpdatedBy = reader["LastUpdatedBy"] as Guid?,
                            CreatedBy = reader["CreatedBy"] as Guid?

                        });
                    }
                }
            }
            return machineMasterList;
        }


    }

}
