﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.DAL.Repositories
{
    public class ItemMasterRepository : IItemMasterRepository
    {
        private readonly SqlConnection _connection;
        private readonly SqlTransaction _transaction;

        public ItemMasterRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public ItemMaster Add(ItemMasterCreateDto itemMasterDto)
        {

            var itemMaster = new ItemMaster
            {
                ItemCode = itemMasterDto.ItemCode,
                Description = itemMasterDto.Description,
                //CreatedBy = itemMasterDto.CreatedBy,
                CreatedOn = DateTime.Now,
                LocCode = itemMasterDto.LocCode,
                CompanyCode = itemMasterDto.CompanyCode,
                IsDeleted = false,
                Length = itemMasterDto.Length
            };

            var query = @"INSERT INTO ItemMaster (ITEM_CODE, DESCRIPTION,CREATED_BY, CREATED_ON, IS_DELETED, LOC_CODE, COMPANY_CODE, ITEM_MASTER_UUID, LENGTH)
                  VALUES (@ItemCode, @Description,@CreatedBy, @CreatedOn, @IsDeleted, @LocCode, @CompanyCode, NEWID(), @Length);
                  SELECT SCOPE_IDENTITY();";

            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@ItemCode", itemMaster.ItemCode);
            command.Parameters.AddWithValue("@Description", itemMaster.Description ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CreatedBy", itemMaster.CreatedBy ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@CreatedOn", itemMaster.CreatedOn);
            command.Parameters.AddWithValue("@IsDeleted", itemMaster.IsDeleted);
            command.Parameters.AddWithValue("@LocCode", itemMaster.LocCode);
            command.Parameters.AddWithValue("@CompanyCode", itemMaster.CompanyCode ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Length", itemMaster.Length);

            command.ExecuteNonQuery();

            return itemMaster;
        }

        public bool Update(ItemMasterUpdateDto itemMasterUpdateDto)
        {
            var checkQuery = "SELECT COUNT(1) FROM ItemMaster WHERE ITEM_MASTER_UUID = @ItemMasterUuid AND IS_DELETED=0";
            using var checkCommand = new SqlCommand(checkQuery, _connection, _transaction);
            checkCommand.Parameters.AddWithValue("@ItemMasterUuid", itemMasterUpdateDto.ItemMasterUuid);

            var exists = (int)checkCommand.ExecuteScalar() > 0;

            if (!exists)
            {

                return false;
            }
            
            var query = @"UPDATE ItemMaster SET ITEM_CODE = @ItemCode, DESCRIPTION = @Description, LAST_UPDATED_BY = @LastUpdatedBy,
                      LAST_UPDATED_ON = @LastUpdatedOn, LOC_CODE = @LocCode, COMPANY_CODE = @CompanyCode, LENGTH = @Length
                      WHERE ITEM_MASTER_UUID = @ItemMasterUuid";
            using var command = new SqlCommand(query, _connection, _transaction);

            command.Parameters.AddWithValue("@ItemCode", itemMasterUpdateDto.ItemCode);
            command.Parameters.AddWithValue("@Description", itemMasterUpdateDto.Description ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LastUpdatedBy", itemMasterUpdateDto.LastUpdatedBy ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@LastUpdatedOn", DateTime.Now);
            command.Parameters.AddWithValue("@LocCode", itemMasterUpdateDto.LocCode);
            command.Parameters.AddWithValue("@CompanyCode", itemMasterUpdateDto.CompanyCode ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Length", itemMasterUpdateDto.Length);
            command.Parameters.AddWithValue("@ItemMasterUuid", itemMasterUpdateDto.ItemMasterUuid);
            var rowsAffected = command.ExecuteNonQuery();
            return rowsAffected > 0;

        }

        public bool Delete(Guid itemMasterUuid)
        {
            var checkQuery = "SELECT COUNT(1) FROM ItemMaster WHERE ITEM_MASTER_UUID = @ItemMasterUuid AND IS_DELETED=0";
            using var checkCommand = new SqlCommand(checkQuery, _connection, _transaction);
            checkCommand.Parameters.AddWithValue("@ItemMasterUuid", itemMasterUuid);

            var exists = (int)checkCommand.ExecuteScalar() > 0;

            if (!exists)
            {

                return false;
            }
            var query = "UPDATE ItemMaster SET IS_DELETED=1 WHERE ITEM_MASTER_UUID=@ItemMasterUuid";

            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@ItemMasterUuid", itemMasterUuid);
            var rowsAffected = command.ExecuteNonQuery();
            return rowsAffected > 0;
        }

        public ItemMaster GetById(Guid itemMasterUuid)
        {
            var query = "SELECT * FROM ItemMaster WHERE ITEM_MASTER_UUID = @ItemMasterUuid AND IS_DELETED=0";
            using var command = new SqlCommand(query, _connection, _transaction);
            command.Parameters.AddWithValue("@ItemMasterUuid", itemMasterUuid);
            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                return new ItemMaster
                {
                    ItemMasterUuid = reader.GetGuid("ITEM_MASTER_UUID"),
                    ItemCode = reader.GetString("ITEM_CODE"),
                    Description = reader["DESCRIPTION"] as string,
                    CreatedBy = reader["CREATED_BY"] as Guid?,
                    CreatedOn = reader["CREATED_ON"] as DateTime?,
                    LastUpdatedBy = reader["LAST_UPDATED_BY"] as Guid?,
                    LastUpdatedOn = reader["LAST_UPDATED_ON"] as DateTime?,
                    IsDeleted = reader.GetBoolean("IS_DELETED"),
                    LocCode = reader.GetString("LOC_CODE"),
                    CompanyCode = reader["COMPANY_CODE"] as string,
                    Length = reader.GetInt32("LENGTH"),
                };
            }
            return null;
        }

        public IEnumerable<ItemMaster> GetAll()
        {
            var query = "SELECT * FROM ItemMaster";
            using var command = new SqlCommand(query, _connection, _transaction);
            using var reader = command.ExecuteReader();
            var items = new List<ItemMaster>();
            while (reader.Read())
            {
                items.Add(new ItemMaster
                {
                    ItemMasterUuid = reader.GetGuid("ITEM_MASTER_UUID"),
                    ItemCode = reader.GetString("ITEM_CODE"),
                    Description = reader["DESCRIPTION"] as string,
                    CreatedBy = reader["CREATED_BY"] as Guid?,
                    CreatedOn = reader["CREATED_ON"] as DateTime?,
                    LastUpdatedBy = reader["LAST_UPDATED_BY"] as Guid?,
                    LastUpdatedOn = reader["LAST_UPDATED_ON"] as DateTime?,
                    IsDeleted = reader.GetBoolean("IS_DELETED"),
                    LocCode = reader.GetString("LOC_CODE"),
                    CompanyCode = reader["COMPANY_CODE"] as string,
                    Length = reader.GetInt32("LENGTH"),
                });
            }
            return items;
        }



        public List<ItemMaster> GetPaginatedItemMasters(ItemMasterRequestDto requestDto)
        {
            try
            {
                var itemMasterList = new List<ItemMaster>();
                var query = "SELECT ITEM_CODE,DESCRIPTION,CREATED_ON,LAST_UPDATED_ON,LOC_CODE,COMPANY_CODE,LENGTH,ITEM_MASTER_UUID FROM ItemMaster ";
                if (!string.IsNullOrEmpty(requestDto.SearchTerm))
                {
                    query += " WHERE ITEM_CODE LIKE @SearchTerm ";
                }
                var sortDirection = requestDto.SortDescending ? "DESC" : "ASC";
                query += "ORDER BY " + requestDto.SortBy + " " + sortDirection;

                query += " OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";
                using (var command = new SqlCommand(query, _connection, _transaction))
                {
                    command.Parameters.AddWithValue("@Offset", (requestDto.Page - 1) * requestDto.PageSize);
                    command.Parameters.AddWithValue("@PageSize", requestDto.PageSize);
                    if (!string.IsNullOrEmpty(requestDto.SearchTerm))
                    {
                        command.Parameters.AddWithValue("@SearchTerm", "%" + requestDto.SearchTerm + "%");
                    }
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            itemMasterList.Add(new ItemMaster
                            {
                                ItemCode = reader.GetString(0),
                                Description = reader.GetString(1),
                                CreatedOn = reader.GetDateTime(2),
                                LastUpdatedOn = reader.GetDateTime(3),
                                LocCode = reader.GetString(4),
                                CompanyCode = reader.GetString(5),
                                Length = reader.GetInt32(6),
                                ItemMasterUuid = reader.GetGuid(7)

                            });
                        }
                    }
                }
                return itemMasterList;
            }
            catch (Exception ex) {
                throw new Exception(ex.Message, ex);
            }
        }


    }
}
