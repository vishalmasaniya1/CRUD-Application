﻿using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.DAL.Repositories
{
    public interface IItemMasterRepository
    {
        ItemMaster Add(ItemMasterCreateDto itemMasterCreateDto);
        bool Update(ItemMasterUpdateDto itemMasterUpdateDto);
        bool Delete(Guid itemMasterUuid);
        ItemMaster GetById(Guid itemMasterUuid);
        IEnumerable<ItemMaster> GetAll();
        List<ItemMaster> GetPaginatedItemMasters(ItemMasterRequestDto requestDto);
    }
}
