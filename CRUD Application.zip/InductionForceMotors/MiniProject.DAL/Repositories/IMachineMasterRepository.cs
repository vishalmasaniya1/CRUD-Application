﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiniProject.Models.DTOs;
using MiniProject.Models.Entities;

namespace MiniProject.DAL.Repositories
{
    public interface IMachineMasterRepository
    {
        void Add(MachineMaster machineMaster);                 
        MachineMaster GetByUuid(Guid machineMasterUuid);       
        IEnumerable<MachineMaster> GetAll();                   
        void Update(MachineMasterUpdateDto machineMasterUpdateDto);              
        void Delete(Guid machineMasterUuid);
        public List<MachineMaster> GetPaginatedMachineMasters(MachineMasterRequestDto requestDto);
    }
}
