﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using MiniProject.DAL.Repositories;

namespace MiniProject.DAL.DatabaseInitializer
{
    public class DatabaseInitializer
    {
        private readonly IConfiguration _configuration;

        public DatabaseInitializer(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void Initialize()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (var connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    ExecuteSqlScript(connection, "CreateDatabase.sql");
                    ExecuteSqlScript(connection, "ItemMaster.sql");
                    ExecuteSqlScript(connection, "MachineMaster.sql");


                }
                catch (Exception ex)
                {
                    
                    throw new InvalidOperationException("Error initializing the database", ex);
                }
            }
        }

        private void ExecuteSqlScript(SqlConnection connection, string scriptName)
        {
            
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Scripts", scriptName);
            var script = File.ReadAllText(filePath);

            
            using (var command = new SqlCommand(script, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }
}
